# Instagram-Clone-Project

MySQL project which is a cloned mimic version of Instagram database. It is used to perform data analysis for real world business related questions and scenarios such as

find out the rewarding system for the loyal users
launching campaign to target the weekdays with the most user registerations
encouraging inactive users to log in back to the system
etc.
